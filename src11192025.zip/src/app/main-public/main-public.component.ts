import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-main-public',
  imports: [RouterLink],
  templateUrl: './main-public.component.html',
  styleUrl: './main-public.component.css'
})
export class MainPublicComponent {

}
